import React from "react";

class AllTeam extends React.Component {
  constructor(props) {
    super(props);
    this.name = props.name;
    this.state = {
      run0: 0,
      run1: 0,
      run2: 0,
      run3: 0,
      run4: 0,
      run6: 0,
      totalRun: 0,
      ball: 0,
      strikeRate: 0,
    };
  }

  updateRun0 = () => {
    this.setState({ run0: this.state.run0 + 1 });
  };

  updateRun1 = () => {
    this.setState({ run1: this.state.run1 + 1 });
  };

  updateRun2 = () => {
    this.setState({ run2: this.state.run2 + 1 });
  };

  updateRun3 = () => {
    this.setState({ run3: this.state.run3 + 1 });
  };

  updateRun4 = () => {
    this.setState({ run4: this.state.run4 + 1 });
  };

  updateRun6 = () => {
    this.setState({ run6: this.state.run6 + 1 });
  };

  updateBall = () => {
    this.setState({ ball: this.state.ball + 1 });
  };

  render() {
    return (
      <div>
        <table className=" table shadow table-bordered ms-5 mt-4">
          <thead>
            <tr>
              <th>Player Name</th>
              <th>Dot Ball</th>
              <th>1 Run</th>
              <th>2 Runs</th>
              <th>3 Runs</th>
              <th>4 Runs</th>
              <th>6 Runs</th>
              <th>Ball</th>
              <th>Total Runs</th>
              <th>Strick Rate</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td className=" text-bg-light">{this.name}
              </td>
              <td>
                <button className="btn btn-danger" onClick={this.updateRun0}>
                  {this.state.run0}
                  </button>
                  </td>
              <td>
                <button className="btn btn-primary" onClick={this.updateRun1}>
                  {this.state.run1}
                  </button>
                  </td>
              <td>
                <button className=" btn btn-danger" onClick={this.updateRun2}>
                  {this.state.run2}
                  </button>
                  </td>
              <td>
                <button className="btn btn-primary" onClick={this.updateRun3}>
                  {this.state.run3}
                  </button>
                  </td>
              <td>
                <button className="btn btn-danger" onClick={this.updateRun4}>
                  {this.state.run4}
                  </button>
                  </td>
              <td>
                <button className="btn btn-primary" onClick={this.updateRun6}>
                  {this.state.run6}
                  </button>
                  </td>

                  <td>
                <button className="btn btn-danger" onClick={this.updateBall}>
                  {this.state.ball}
                  </button>
                  </td>

              <td className=" text-bg-primary">
                {this.state.totalRun}
              </td>
              <td className=" text-bg-danger">
                {this.state.strikeRate}
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    );
  }
}

export default AllTeam;
