import React from "react";
import AllTeam from "./AllTeam";

class Players extends React.Component {
  render() {
    return (
      <div className="container">
        <div className="row fw-bold">
         <div className=" col-lg-10">
         <AllTeam name="Virat" />
          <AllTeam name="Dhoni" />
          <AllTeam name="Rohit" />
          <AllTeam name="Gill" />
          <AllTeam name="Rishbh Pant" />
         </div>
        
        </div>
      </div>
    );
  }
}

export default Players;
